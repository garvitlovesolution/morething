**What this changes and why:**

- [ ] I tested it in a browser (desktop and phone if relevant)
- [ ] It does not upload user files or text to a server
